var aws = require("aws-sdk");
var iam = new aws.IAM({apiVersion: '2010-05-08'});
var autoscaling = new aws.AutoScaling({apiVersion: '2011-01-01'});


/*
This Lambda function expects input such as this from CloudFormation (Note ResourceProperties):

Most of this is prepopulated by CFN. Only the "ResourceProperties" can be modified by the user
via the CloudFormation template.

{
  "StackId": "arn:aws:cloudformation:us-west-2:EXAMPLE/stack-name/guid",
  "ResponseURL": "http://pre-signed-S3-url-for-response",
  "ResourceProperties": {
    "asgName" : "asjdaad4-Asg-1E6WX8MJYIDAX",
    "asgMin" : 1,
    "asgMax" : 2,
    "asgDesired" : 1
  },
  "RequestType": "Create",
  "ResourceType": "Custom::TestResource",
  "RequestId": "unique id for this create request",
  "LogicalResourceId": "MyTestResource"
}

*/


exports.handler = function(event, context) {

    console.log("REQUEST RECEIVED:\n" + JSON.stringify(event));

    // Initiating empty dict "responseData"
    var responseData = {};
    
    // Populating ASG variables received from CFN for readability
    var asgName = event.ResourceProperties.asgName;
    var asgMin = event.ResourceProperties.asgMin;
    var asgMax = event.ResourceProperties.asgMax;
    var asgDesired = event.ResourceProperties.asgDesired;

    // Do stuff depending on the Request type from CFN
    switch(event.RequestType)
    {
        case "Create":
            // Update min and max via "updateAutoScalingGroup"
            var params = {
                AutoScalingGroupName: asgName,
                MinSize: asgMin,
                MaxSize: asgMax,
                DesiredCapacity: asgDesired,
            };
            autoscaling.updateAutoScalingGroup(params, function(err, data) {
                if (err) {                            // an error occurred
                    console.log("ASG update failure: ", err, err.stack);
                    sendResponse(event, context, "FAILED", responseData);
                }
                else {                                // successful response
                    console.log("ASG update success: ", data);           
                    sendResponse(event, context, "SUCCESS", responseData);
                }
            });
            
            break;
        case "Delete":
            sendResponse(event, context, "SUCCESS", responseData);
            break;
        case "Update":
            sendResponse(event, context, "SUCCESS", responseData);
            break;  
    }
};

// Function reponsible for sending responses back to CFN
function sendResponse(event, context, responseStatus, responseData) {
 
    var responseBody = JSON.stringify({
        Status: responseStatus,
        Reason: "See the details in CloudWatch Log Stream: " + context.logStreamName,
        PhysicalResourceId: context.logGroupName,
        StackId: event.StackId,
        RequestId: event.RequestId,
        LogicalResourceId: event.LogicalResourceId,
        Data: responseData.message
    });
 
    console.log("RESPONSE BODY:\n", responseBody);
 
    var https = require("https");
    var url = require("url");
 
    var parsedUrl = url.parse(event.ResponseURL);
    var options = {
        hostname: parsedUrl.hostname,
        port: 443,
        path: parsedUrl.path,
        method: "PUT",
        headers: {
            "content-type": "",
            "content-length": responseBody.length
        }
    };
 
    console.log("SENDING RESPONSE...\n" );
 
    var request = https.request(options, function(response) {
        console.log("STATUS: " + response.statusCode);
        console.log("HEADERS: " + JSON.stringify(response.headers));
        context.done();
    });
 
    request.on("error", function(error) {
        console.log("sendResponse Error:" + error);
        context.done();
    });

    request.write(responseBody);
    request.end();
}
